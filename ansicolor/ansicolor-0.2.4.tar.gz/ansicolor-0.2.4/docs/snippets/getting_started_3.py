from ansicolor import Colors
from ansicolor import colorize

print(colorize('''"I'm blue", said the smurf.''', Colors.Blue, start=1, end=9))
