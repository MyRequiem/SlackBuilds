from ansicolor import red
from ansicolor import write_out

write_out(red("This looks red in a terminal.\n"))
