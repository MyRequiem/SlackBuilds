from ansicolor import Colors
from ansicolor import colorize

print(colorize("I'm blue", Colors.Blue))
