ansicolor.demos module
======================

.. automodule:: ansicolor.demos
    :members:
    :undoc-members:
    :show-inheritance:
