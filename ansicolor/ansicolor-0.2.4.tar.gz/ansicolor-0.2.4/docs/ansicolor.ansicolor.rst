ansicolor.ansicolor module
==========================

.. automodule:: ansicolor.ansicolor
    :members:
    :undoc-members:
    :show-inheritance:
