ansicolor
=========


User guide
----------

.. toctree::
   :maxdepth: 4

   src/getting_started.rst
   src/using_highlights.rst
   src/colored_diffs.rst
   src/marked_up_strings.rst


API documentation
-----------------

.. toctree::
   :maxdepth: 4

   ansicolor


Project documentation
---------------------

.. toctree::
   :maxdepth: 4

   src/changes.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
