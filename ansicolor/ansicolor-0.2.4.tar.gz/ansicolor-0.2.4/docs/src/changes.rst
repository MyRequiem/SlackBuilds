Release notes
=============


0.2.4
-----

- First version supporting Python 3.4!

0.2.3
-----

- :func:`ansicolor.highlight_string` accepts a new kwarg `colors`. `color` has been
  deprecated.

0.2.2
-----

- :func:`ansicolor.colorize` now accepts ``start`` and ``end`` kwargs.
  :func:`ansicolor.wrap_string` has been deprecated.
