try:
    # 3.3 and later
    import unittest.mock as mock
except ImportError:
    # You need to install 'mock' package before running
    import mock
