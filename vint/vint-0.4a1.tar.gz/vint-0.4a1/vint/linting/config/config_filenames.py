CONFIG_FILENAMES = [
    '.vintrc.yaml',
    '.vintrc.yml',
    '.vintrc',
]
